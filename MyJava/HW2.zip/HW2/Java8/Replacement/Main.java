package HW2.Java8.Replacement;

public class Main {
    public static void main(String[] args) {
        String input = "walabcwalexywalxzsfwalmx";
        String replaced = input.replace("wal", "sams");
        System.out.println(replaced);
    }
}
