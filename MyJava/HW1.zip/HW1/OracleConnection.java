package HW1;
// oop1


public class OracleConnection implements DatabaseConnection {
    
}


