package HW1;
// oop1


public class MySqlConnection implements DatabaseConnection {
    
}


