package HW1;
// oop1


public class SqlServerConnection implements DatabaseConnection {
    
}


