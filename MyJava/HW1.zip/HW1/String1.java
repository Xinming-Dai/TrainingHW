package HW1;
public class String1 {
    public static void main(String[] args){
        String myString = "Algorithms";
        System.out.println(myString.substring(2, 4));
        System.out.println(myString.substring(0, 4));
    }
}