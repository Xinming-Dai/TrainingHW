package HW1;
// Static 1

public class Book {
    static String[] id, isbn, name, author, publishDate;
    static {
        id = new String[]{"0001", "0002", "0003"};
        isbn = new String[]{"0001", "0002", "0003"};
        name = new String[]{"0001", "0002", "0003"};
        author = new String[]{"0001", "0002", "0003"};
        publishDate = new String[]{"0001", "0002", "0003"};
    }
}
