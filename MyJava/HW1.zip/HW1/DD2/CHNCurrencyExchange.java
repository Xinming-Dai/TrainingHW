package HW1.DD2;

public class CHNCurrencyExchange implements CurrencyExchange{
    
    public Currency getCurrency(){
        return new Currency("CHN");
    }
}
