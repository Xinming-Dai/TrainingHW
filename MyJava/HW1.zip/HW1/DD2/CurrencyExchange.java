package HW1.DD2;

interface CurrencyExchange {
    public Currency getCurrency();
}
