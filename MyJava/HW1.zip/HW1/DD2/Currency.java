package HW1.DD2;

public class Currency {
    String country;

    public Currency(String country){
        this.country = country;
    }
}
