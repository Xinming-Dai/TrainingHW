package HW1;

public final class Final {
   
    public final void finalMethod(){
        final String[] myArray = {"asfae"};
        myArray[0] = "dasfasta";
    }
}
