package HW1;
// oop1


interface DatabaseConnection {
    public static void getConnection(){}
}
